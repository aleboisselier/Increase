![Increase logo](http://open-beer.kobject.net/img/Increase.png "Increase logo")

# Increase
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/aleboisselier/Increase/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/aleboisselier/Increase/?branch=master)

A Phalcon web application to manage the progress of projects, and improve communication with the customer
