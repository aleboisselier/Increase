<!DOCTYPE html>
<html>
	<head>
		<title>Increase</title>
		<?php echo $this->tag->stylesheetLink('css/bootstrap.min.css'); ?>
		<?php echo $this->tag->stylesheetLink('css/styles.css'); ?>
		<?php echo $this->tag->javascriptInclude('js/jquery.min.js'); ?>
		<?php echo $this->tag->javascriptInclude('js/bootstrap.min.js'); ?>
		
		<?php echo $this->tag->stylesheetLink('css/rangeslider.css'); ?>
		<?php echo $this->tag->javascriptInclude('js/rangeslider.min.js'); ?>

		<link rel="icon" href="<?php echo $siteUrl; ?>img/increase.png" >
		<script src="<?php echo $siteUrl; ?>js/menu.js" type="text/javascript"></script>
	</head>
	<meta charset="UTF-8">
	<body>
		<div id="wrapper">
			<div class="display"></div>
	
	        <!-- Sidebar -->
	        <div id="sidebar-wrapper">
	            <ul class="sidebar-nav">
	            	<div class="display-user">
						<img src="<?php echo $siteUrl; ?>img/user.png" class="img-responsive" alt="Responsive image" style="float:left; margin-left:20%;">
						<div class="infoUser">
						<?php if (isset($viewUser)) { ?>
							<?php echo $viewUser; ?>
						<?php } ?>
						</div>
					</div>
					<div class="bs-docs-header">
						<img src="<?php echo $siteUrl; ?>img/phalcon.png" class="img-responsive" alt="Responsive image">
					</div>
					<div class="row" style="margin:0px;">
						<div class="col-md-4 col-xs-4"></div>
						<div class="img-logo col-md-4 col-xs-4" style="padding:0%">
							<img src="<?php echo $siteUrl; ?>img/Increase.png" class="img-responsive" alt="Responsive image">
						</div>
					</div>
					<br>
					<li>
	                    <a href="<?php echo $this->url->get('Index'); ?>"><span class="glyphicon glyphicon-home" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Accueil</a>
	                </li>
	                <li>
			          <a href="<?php echo $this->url->get('Users'); ?>" data-ajax="Users" class="menuItem"><span class="glyphicon glyphicon-user" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Utilisateurs</a>
	                </li>
		            <li>
	                    <a href="<?php echo $this->url->get('Roles'); ?>" data-ajax="Roles" class="menuItem"><span class="glyphicon glyphicon-tags" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp; Rôles</a>
	                </li>
	                <li>
	                    <a href="<?php echo $this->url->get('Users'); ?>" data-ajax="Projects" class="menuItem"><span class="glyphicon glyphicon-book" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Projets</a>
	                </li>
	                <li>
	                    <a href="<?php echo $this->url->get('Messages'); ?>" data-ajax="Messages" class="menuItem"><span class="glyphicon glyphicon-comment" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Messages</a>
	                </li>
	                <li>
	                    <a href="<?php echo $this->url->get('UseCases'); ?>" data-ajax="UseCases" class="menuItem"><span class="glyphicon glyphicon-briefcase" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Use Cases</a>
	                </li>
	                <li>
	                    <a href="<?php echo $this->url->get('Taches'); ?>" data-ajax="Taches" class="menuItem"><span class="glyphicon glyphicon-tasks" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Tâches</a>
	                </li>
	                <li>
	                    <a data-ajax="Auth/logout/true" class="menuItem"><span class="glyphicon glyphicon-log-out" aria-hidden="true" style="margin-left:-10%;"></span>&nbsp;Déconnexion</a>
	                </li>
	            </ul>
	        </div>
	        <!-- /#sidebar-wrapper -->
	
	        <!-- Page Content -->
	        <div id="page-content-wrapper">
	            <div class="container-fluid" style="margin:0px; padding:0px;">
	                <div class="header">
	                	<div id="menu-toggle">
		                	<span  class=" glyphicon glyphicon-menu-hamburger"></span>
		                	Menu
	                	</div>
	                	<br>
						<p>
							<span class="title">Increase :</span>
							 Gérez la <b>progression</b> de vos projets, améliorez la <b>communication</b> 
							avec vos clients.
						</p>
					</div>
					<div class="bread">
						<ol class="breadcrumb">
							<li><a href="<?php echo $siteUrl; ?>Index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Accueil</a></li>
							<?php if (isset($ControllerName) && $title != '') { ?><li <?php if (isset($ObjectName)) { ?>class="active"<?php } ?>><a href="<?php echo $siteUrl; ?><?php echo $ControllerName; ?>"><span class="glyphicon glyphicon-<?php echo $controllerIcon; ?>" aria-hidden="true"></span>&nbsp;<?php echo $title; ?></a></li><?php } ?>
							<li class="active objectBreadcrumb"><?php if (isset($ObjectName)) { ?><?php echo $ObjectName; ?><?php } ?></li>
						</ol>
					</div>
					<div class="content">
						<div id="message"></div>
						<div id="content">
							<?php echo $this->getContent(); ?>
						</div>
					</div>
				</div>
	        </div>
	        <!-- /#page-content-wrapper -->
	
	    </div>
	    <!-- /#wrapper -->
	</body>
	</html>