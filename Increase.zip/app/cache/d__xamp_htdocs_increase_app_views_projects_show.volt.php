<style>
<!--
.content{
	padding:0;
}
#content{
	padding:0;
}
-->
</style>
<fieldset>
	<div class="col-md-3 col-xs-3 ticket" id="color">
		<div class="imgProjet row">
			<?php if ($projet->getImage() == null) { ?>
				<img src="<?php echo $siteUrl; ?>img/phalconIcon.png" class="img-circle" alt="imageProject" id="imageProject" style="width:100%">
			<?php } else { ?>
				<img src="<?php echo $siteUrl . $projet->getImage(); ?>" class="img-circle" alt="imageProject" id="imageProject" style="width:100%">
			<?php } ?>
		</div>
		<div class="client row">
			<?php echo $projet->getClient(); ?>
		</div>
		<div class="percentage"> 
			<?php echo $projet->getAvancement(); ?> %
		</div>
			
	</div>
	<div class="form-group col-md-7 col-xs-7 projectContent" style="margin-left:5%">
		<h1 class="titleProject"><?php echo $projet; ?></h1>
		<div class="date row">
			<div class="col-md-10">Lancement : <?php echo $projet->getDateLancement(); ?> // Fin prévue : <?php echo $projet->getDateFinPrevue(); ?></div>
		</div>
		<br>
		Temps Ecoulé : 
		<div class="progress">
			<div class="progress-bar progress-bar-success" 
				role="progressbar" 
				aria-valuenow="40" 
				aria-valuemin="0" 
				aria-valuemax="100" 
				style="width: <?php echo $tmpEcoule; ?>">
				<?php if ($tmpEcoule == '0%') { ?>
					<b style="color:red"><?php echo $tmpEcoule; ?></b>
				<?php } else { ?>
					<b><?php echo $tmpEcoule; ?></b>
				<?php } ?>
			</div>
			
		</div>
		Pourcentage du projet effectué : 
		<div class="progress">
			<div class="progress-bar progress-bar-info" 
				role="progressbar" 
				aria-valuenow="<?php echo $projet->getAvancement(); ?>" 
				aria-valuemin="0" 
				aria-valuemax="100" 
				style="width: <?php echo $projet->getAvancement(); ?>%">
				<?php if ($projet->getAvancement() == 0) { ?>
					<b style="color:red"><?php echo $projet->getAvancement(); ?>%</b>
				<?php } else { ?>
					<b><?php echo $projet->getAvancement(); ?>%</b>
				<?php } ?>
			</div>
		</div>
		<br>
		<div class="description">
			<h3>Description : </h3>
			<?php echo $projet->getDescription(); ?>
		</div>
		
		<table class="taskRepeat" style="display:none;" >
		<tr>
			<td class="col-md-6">[[libelle]]</td>
			<td class="col-md-6">
				<div class="progress">
					<div class="progress-bar progress-bar-success" role="progressbar"
						aria-valuenow="[[avancement]]" aria-valuemin="0"
						aria-valuemax="100" style="width: [[avancement]]%;">[[avancement]]%</div>
				</div>
			</td>
		</tr>	
		</table>

		<h3>Use Cases : </h3>
		<div class="btn btn-primary btn-block displayUcs">Afficher les Use Cases</div>
		<div class="btn btn-primary btn-block hideUcs" style="display:none">Cacher les Use Cases</div>
		<div class="ucs" style="display:none;">
		<br>
			<?php foreach ($ucs as $u) { ?>
				<div class="panel panel-default">
	  				<div class="panel-heading">
		  				<?php echo $u; ?>
						<?php if ($this->length($tachesUcs[$u->getCode()]) > 0) { ?>							
	  						<a class="loadTasks" id="<?php echo $u->getCode(); ?>" data-ajax="Json/listTaches/<?php echo $u->getCode(); ?>">
	  							<span class="glyphicon glyphicon-eye-open pull-right" style="color:rgba(0,0,0,0.7); cursor:pointer"></span>
	  						</a>
	  						<a class="hideTasks" id="<?php echo $u->getCode(); ?>" style="display:none;">
	  							<span class="glyphicon glyphicon-eye-close pull-right" style="color:rgba(0,0,0,0.7); cursor:pointer"></span>
	  						</a>
	  					<?php } ?>
					</div>
					<div class="viewUc" id="<?php echo $u->getCode(); ?>">
		  				<table class="table" id="<?php echo $u->getCode(); ?>" style="display:none">
					  	</table>
				  	</div>
				</div>
			<?php } ?>
		</div>
		<a data-ajax="<?php echo 'Projects/manage/' . $projet->getId(); ?>" class="manageBtn">
			<div class='btn btn-default btn-block' >Ajouter/Modifier un Use Case</div>
		</a>
		
		<h3>Messages : </h3>
		
		<?php if ($nbMessages > 0) { ?>
			<a href="" data-ajax="Json/loadMessages/<?php echo $projet->getId(); ?>" class="btn btn-primary loadMessages btn-block" >Afficher <?php echo $nbMessages; ?> message<?php if ($nbMessages > 1) { ?>s<?php } ?>.</a>
		<?php } else { ?>
			<a class="btn btn-primary load btn-block disabled">Aucun Message à Afficher.</a>
		<?php } ?>
				
	<div class="messages" style="display:none">
		<a class="btn btn-primary load btn-block hideMessages">Masquer les Messages</a>
		<a class="btn btn-primary newMessage btn-block"  style="margin-bottom: 25px;">Nouveau Message</a>
		<div class="msgTemplate">
			<div class="col-md-11 pull-right" style="padding:0">
				<div class="panel panel-default">
					<div class="panel-heading">
						<span>[[objet]]
							<small>Auteur :
								<i style="font-size:12px">[[author]]</i>
							</small>
						</span>
					</div>
				  	<div class="panel-body" id="[[id]]">
				  		<i>[[content]]</i>
				  		<small class="pull-right">Il y a [[date]]</small>
				  	</div>
				  	<div class="panel-footer">
				  		<button class="btn btn-xs btn-default newResponse" id="[[id]]"><span class="glyphicon glyphicon-share-alt"></span></button>
				  		<small class="pull-right"> <a id="[[id]]" class="loadReponses" data-ajax="Json/loadMessages/<?php echo $projet->getId(); ?>/[[id]]" >Afficher [[responses]] réponses</a></small>
				  		<div class="clearfix"></div>
				  	</div>
				</div>
				<div class="responses [[id]]"></div>
			</div>
		</div>
	</div>
			<br><br>
	
</fieldset>

	<form action="messages/updateProject"  method="post" style="display: none;" class="msgForm model">
		<div class="col-md-12">
			<fieldset>
				<div class="form-group">
					<input type="hidden" name="id" id="id" value="">
					<input type="hidden" name="idProjet" value="<?php echo $projet->getId(); ?>">
					<input type="hidden" name="idUser" value="<?php echo $currUser->getId(); ?>">
					<input type="hidden" name="idFil" id="idFil" value="<?php echo $currUser->getId(); ?>">
				</div>
				  <div class="form-group">
					<label for="libelle">Objet</label>
					<input type="text" name="objet" id="objet" class="form-control" value=""/>
				</div>
				<div class="form-group">
					<label for="libelle">Message</label>
					<textarea name="content" id="content" class="form-control"></textarea>
				</div>
				<div class="form-group">
					<input type="submit" value="Envoyer" class="btn btn-default validate">
					<button class="btn btn-default cancel">Annuler</button>
				</div>
			</fieldset>
		</div>
	</form>

<?php echo $script_foot; ?>
