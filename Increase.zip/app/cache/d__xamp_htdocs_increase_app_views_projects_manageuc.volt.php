<?php echo $this->tag->form(array('usecases/updateFromProject', 'method' => 'post', 'name' => 'frmObject', 'id' => 'frmObject')); ?>
	<fieldset>
	<legend>Ajouter/modifier une UseCase : <?php echo $usecase; ?></legend>
		<div class="form-group">
			<input type="hidden" name="id" id="id" value="<?php echo $usecase->getId(); ?>">
		</div>		
		<div class="form-group">
			<label for="libelle">Code</label>
			<input type="text" name="code" id="code" class="form-control" value="<?php echo $usecase->getCode(); ?>" <?php if ($usecase->getCode() != '') { ?>disabled<?php } ?> />
		</div>
		<div class="form-group">
			<label for="libelle">Nom</label>
			<input type="text" name="nom" id="nom" class="form-control" value="<?php echo $usecase->getNom(); ?>"/>
		</div>
		<input type="hidden" value="<?php echo $usecase->getIdProjet(); ?>" name="idProjet">
		<div class="form-group">
		    <label for="idUser">Développeur</label>
		    <select class="form-control" name="idDev">
				<?php foreach ($users as $user) { ?>
					<option value="<?php echo $user->getId(); ?>" <?php if ($user->getId() == $usecase->getIdDev()) { ?>selected<?php } ?>><?php echo $user->getIdentite(); ?></option>
				<?php } ?>
			</select>
		  </div>
		<div class="form-group">
			<label for="libelle">Poids</label>
			<input type="text" name="poids" id="poids" class="form-control" value="<?php echo $usecase->getPoids(); ?>"/>
		</div>
		<div class="form-group">
			<label for="avancement">Avancement</label>
			<input type="range" min="0" max="100" step="1" value="<?php echo $usecase->getAvancement(); ?>" data-orientation="horizontal" name="avancement" id="avancement" disabled>
			<div><h1 class="avancement text-center"><?php echo $usecase->getAvancement(); ?>%</h1></div>
		</div>
		
		<div class="form-group">
			<input type="submit" value="Valider" class="btn btn-default validateUpUc">
			<a class="btn btn-default cancel" >Annuler</a>
		</div>
		<div class="form-group">
			<select class="form-control selectTasks" id="selectTasks" onChange="var e = document.getElementById('selectTasks');var str = e.options[e.selectedIndex].value;e.setAttribute('data-ajax',str);" >
				<option value="Projects/manageTasks">Choisissez une Tâche...</option>
				<option class="optionUc" value="Projects/manageTasks/null/<?php echo $usecase->getCode(); ?>">Ajouter une nouvelle Tâche</option>
				<?php foreach ($tasks as $task) { ?>
					<option class="optionUc" id="<?php echo $task->getId(); ?>" value="Projects/manageTasks/<?php echo $task->getId(); ?>">
						<?php echo $task->getLibelle(); ?>
					</option>
				<?php } ?>
			</select>
		</div>
		
	</fieldset>
</form>

<div class="tasks"></div>

<?php echo $script_foot; ?>
