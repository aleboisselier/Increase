id projet : <?php echo $projet->getNom(); ?>
<!-- <?php echo $this->tag->form(array('usecases/update', 'method' => 'post', 'name' => 'frmObject', 'id' => 'frmObject')); ?>
	<fieldset>
	<legend>Ajouter/modifier un Projet</legend>
		<div class="form-group">
			<input type="hidden" name="id" id="id" value="">
		</div>		
		<div class="form-group">
			<label for="libelle">Code</label>
			<input type="text" name="code" id="code" class="form-control" />
		</div>
		<div class="form-group">
			<label for="libelle">Nom</label>
			<input type="text" name="nom" id="nom" class="form-control"/>
		</div>
		id P: <?php echo $projet->getId(); ?><?php echo $projet->getNom(); ?>
		
		<input type="text" value="" name="idProjet">
		<div class="form-group">
		    <label for="idUser">Développeur</label>
		    <select class="form-control" name="idDev">
				<?php foreach ($users as $user) { ?>
					<option value="<?php echo $user->getId(); ?>"><?php echo $user->getIdentite(); ?></option>
				<?php } ?>
			</select>
		  </div>
		<div class="form-group">
			<label for="libelle">Poids</label>
			<input type="text" name="poids" id="poids" class="form-control"/>
		</div>
		<div class="form-group">
			<input type="hidden" name="avancement" id="avancement" value="0">
		</div>
		<div class="form-group">
			<input type="submit" value="Valider" class="btn btn-default validateUpUc">
			<a class="btn btn-default cancel" href="" data-ajax="<?php echo $baseHref . '/index'; ?>">Annuler</a>
		</div>
	</fieldset>
</form>
<?php echo $script_foot; ?>-->