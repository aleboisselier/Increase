<?php echo $this->tag->form(array('Role/update', 'method' => 'post', 'name' => 'frmObject', 'id' => 'frmObject')); ?>
	<fieldset>
	<legend>Ajouter/modifier un Rôle</legend>
		<div class="form-group">
			<input type="hidden" name="id" id="id" value="<?php echo $role->getId(); ?>">
		</div>
		<div class="form-group">
			<label for="libelle">Libellé</label>
			<input type="text" name="libelle" id="libelle" value="<?php echo $role->getLibelle(); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="libelle">Description</label>
			<textarea name="description" id="description" class="form-control"><?php echo $role->getDescription(); ?></textarea>
		</div>
		<div class="form-group">
			<input type="submit" value="Valider" class="btn btn-default validate">
			<a class="btn btn-default cancel" href="<?php echo $this->url->get('Roles'); ?>" data-ajax="<?php echo $baseHref . '/index'; ?>">Annuler</a>
		</div>
	</fieldset>
</form>

<hr>
<legend>Droits du Groupe</legend>
<?php echo $this->tag->form(array('Roles/update', 'method' => 'post', 'name' => 'frmObject', 'id' => 'frmObject')); ?>
<input type="hidden" value="<?php echo $role->getId(); ?>"  name="idRole"/>
<?php foreach ($controllers as $key => $controller) { ?>
<div class="col-md-6">
<div class="panel panel-success">
	<div class="panel-heading"><h3 class="panel-title"><?php echo $controller['name']; ?></h3></div>
		<div class="panel-body">
			<div class="row">
				<?php foreach ($controllers['Default']['actions'] as $actionKey => $action) { ?>
					<div class="col-md-3">
						<div class="checkbox"><label><input name="acl[]" type="checkbox" value="<?php echo $key; ?>/<?php echo $actionKey; ?>" <?php if (isset($acls[$key][$actionKey])) { ?>checked<?php } ?>> <?php echo $action; ?></label></div>
					</div>
				<?php } ?>
				<?php if ($key != 'Default') { ?>
					<?php foreach ($controller['actions'] as $actionKey => $action) { ?>
						<div class="col-md-3">
							<div class="checkbox"><label><input name="acl[]" type="checkbox" value="<?php echo $key; ?>/<?php echo $actionKey; ?>" <?php if (isset($acls[$key][$actionKey])) { ?>checked<?php } ?>> <?php echo $action; ?></label></div>
						</div>
					<?php } ?>
				<?php } ?>
			</div>
		</div>
	</div>
	</div>
<?php } ?>
<div class="form-group">
	<input type="submit" value="Mettre à jour" class="btn btn-default validateACL">
	<a class="btn btn-default cancel" href="<?php echo $this->url->get('Roles'); ?>" data-ajax="<?php echo $baseHref . '/index'; ?>">Annuler</a>
</div>
</form>

<div class="clearfix"></div>


<?php echo $script_foot; ?>
