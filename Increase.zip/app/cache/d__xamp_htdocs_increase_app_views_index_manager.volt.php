<?php echo $msg; ?>
<h1>Bonjour <?php echo $user; ?> !</h1>
<br>
<ul class="list-group">
 	<li class="list-group-item active">Vos Projets managé :</li>
	<?php foreach ($projectsManager as $projectManager) { ?>
		<a href="#" data-ajax="Projects/show/<?php echo $projectManager->getId(); ?>" class="list-group-item">
			<b><?php echo $projectManager->getNom(); ?></b>
			<div class="progress" style="margin-top:2%;">
				<div class="progress-bar progress-bar-success" role="progressbar"
					aria-valuenow="<?php echo $projectManager->getAvancement(); ?>" aria-valuemin="0"
					aria-valuemax="100" style="width: <?php echo $projectManager->getAvancement(); ?>%;">
					<?php if ($projectManager->getAvancement() == 0) { ?>
						<b style="color:red"><?php echo $projectManager->getAvancement(); ?>%</b>
					<?php } else { ?>
						<b><?php echo $projectManager->getAvancement(); ?>%</b>
					<?php } ?>
				</div>
				<div class="progress-bar progress-bar-warning" style="width: <?php echo 100 - $projectManager->getAvancement(); ?>%">
					<?php echo 100 - $projectManager->getAvancement(); ?>% avant le <?php echo $projectManager->getDateFinPrevue(); ?>
				</div>
			</div>
		</a>
	<?php } ?>
</ul>
<ul class="list-group">
 	<li class="list-group-item active">Vos Projets :</li>
	<?php foreach ($projectsDvlp as $projectDvlp) { ?>
		<a href="#" data-ajax="Projects/show/<?php echo $projectDvlp->getId(); ?>" class="list-group-item">
			<?php echo $projectDvlp->getNom(); ?>
			<div class="progress" style="margin-top:2%;">
				<div class="progress-bar progress-bar-success" role="progressbar"
					aria-valuenow="<?php echo $projectDvlp->getAvancement(); ?>" aria-valuemin="0"
					aria-valuemax="100" style="width: <?php echo $projectDvlp->getAvancement(); ?>%;">
					<?php if ($projectDvlp->getAvancement() == 0) { ?>
						<b style="color:red"><?php echo $projectDvlp->getAvancement(); ?>%</b>
					<?php } else { ?>
						<b><?php echo $projectDvlp->getAvancement(); ?>%</b>
					<?php } ?>
				</div>
				<div class="progress-bar progress-bar-warning" style="width: <?php echo 100 - $projectDvlp->getAvancement(); ?>%">
					<?php echo 100 - $projectDvlp->getAvancement(); ?>% avant le <?php echo $projectDvlp->getDateFinPrevue(); ?>
				</div>
			</div>
		</a>
	<?php } ?>
</ul>
<?php echo $script_foot; ?>