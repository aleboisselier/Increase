<?php echo $this->tag->form(array('projects/update', 'method' => 'post', 'name' => 'frmObject', 'id' => 'frmObject')); ?>
	<fieldset>
	<legend>Ajouter/modifier un Projet</legend>
		<div class="form-group">
			<input type="hidden" name="id" id="id" value="<?php echo $project->getId(); ?>">
		</div>
		<div class="form-group">
			<label for="libelle">Nom</label>
			<input type="text" name="nom" id="nom" value="<?php echo $project->getNom(); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="libelle">Description</label>
			<textarea name="description" id="description" class="form-control"><?php echo $project->getDescription(); ?></textarea>
		</div>
		<div class="form-group">
		    <label for="idClient">Client</label>
		    <select class="form-control" name="idCLient">
				<?php foreach ($clients as $client) { ?>
					<option value="<?php echo $client->getId(); ?>" <?php if ($client->getId() == $project->getIdClient()) { ?>selected<?php } ?>><?php echo $client->getIdentite(); ?></option>
				<?php } ?>
			</select>
		  </div>
		  <div class="form-group">
		    <label for="idClient">Chef de Projet</label>
		    <select class="form-control" name="idManager">
				<?php foreach ($managers as $manager) { ?>
					<option value="<?php echo $manager->getId(); ?>" <?php if ($manager->getId() == $project->getIdManager()) { ?>selected<?php } ?>><?php echo $manager->getIdentite(); ?></option>
				<?php } ?>
			</select>
		  </div>
		<div class="form-group col-md-6">
			<label for="libelle">Date de Lancement</label>
			<input type="date" name="dateLancement" id="dateLancement" class="form-control" value="<?php echo $project->getDateLancement(); ?>"/>
		</div>
		<div class="form-group col-md-6">
			<label for="libelle">Date de Fin Prévue</label>
			<input type="date" name="dateFinPrevue" id="dateFinPrevue" class="form-control" value="<?php echo $project->getDateFinPrevue(); ?>"/>
		</div>
		<div class="form-group">
			<input type="submit" value="Valider" class="btn btn-default validate">
			<a class="btn btn-default cancel" href="<?php echo $this->url->get('projects'); ?>" data-ajax="<?php echo $baseHref . '/index'; ?>">Annuler</a>
		</div>
	</fieldset>
</form>


<?php echo $script_foot; ?>
