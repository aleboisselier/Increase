<fieldset>
	<legend>Gérer un Projet : <a class="" href="<?php echo $baseHref; ?>/Projects/show/<?php echo $project->getId(); ?>"><?php echo $project; ?></a></legend>
	<div class="form-group">
		<select class="form-control selectUc" id="selectUc" onChange="var e = document.getElementById('selectUc');var str = e.options[e.selectedIndex].value;e.setAttribute('data-ajax',str);" >
			<option value="Projects/manageUc">Choisissez une action...</option>
			<option class="optionUc" value="Projects/manageUc/null/<?php echo $project->getId(); ?>">Ajouter un nouvel Use Case</option>
			<?php foreach ($ucs as $uc) { ?>
				<option class="optionUc" id="<?php echo $uc->getId(); ?>" value="Projects/manageUc/<?php echo $uc->getId(); ?>">
					<?php echo $uc->getNom(); ?>
				</option>
			<?php } ?>
		</select>
	</div>
	<div class="infoUc" style="display:none">
	</div>
</fieldset>

<?php echo $script_foot; ?>
